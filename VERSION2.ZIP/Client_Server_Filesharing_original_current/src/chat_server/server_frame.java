//NAME : OMKAR KYATHAM
//STUDENTID : 1001765567

//the package for server class
package chat_server;
//necessary libraries to import & useful java libraries for various actions of the program
import chat_client.client_frame;
import java.awt.Desktop;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.apache.commons.io.FileUtils;

//the main class to run the Jframe components
//https://ideone.com/n2H9Zg
public class server_frame extends javax.swing.JFrame 
{
   //variables to store the connected allclients and their corresponding Outputstreams
   ArrayList Costreams;
   ArrayList<String> allclients;
    //variables to store the Coordinator client and its deleted file path, count of votes, count of allclients, and the voting decision
   String coordinator="";
   String deletefilepath="";
   int countofusers=0;
   int countofvotes=0;
   String votingdecision="Commit";
 InputStream in; 
       Socket sockz;
    OutputStream out;
 ServerSocket serverSock;
    
   //Every client which connects via socket to the server, the server accepts it and assigns a clientHandler for each client
   //the clientHandler connects to the client via printwriter through outputstream and receives data via bufferedreader through inputstream
   //https://stackoverflow.com/questions/37294059/why-cant-i-display-a-string-on-a-textarea-from-a-frame-to-frame-another-with-pr
   public class ClientHandler implements Runnable	
   {
       //Buffered reader is for reading data from inpustream, socket is for storing a socket connection object, printwriter is for outputstreams
       BufferedReader reader;
      
       PrintWriter client;
      
       //a constructor to assign the global variables i.e, client socket & printwriter
       public ClientHandler(Socket clientSocket, PrintWriter user) 
       {
            client = user;
            try 
            {
                sockz = clientSocket;
                in = sockz.getInputStream();
                out = sockz.getOutputStream();
                InputStreamReader iReder = new InputStreamReader(sockz.getInputStream());
                reader = new BufferedReader(iReder);
            }
            catch (Exception ex) 
            {
                ta_chat.append(" Unexpected error... \n");
            }

       }
//a default method for the buffered reader captures the streams of data from client until disconnected/killed
       //https://ideone.com/n2H9Zg
       @Override
       public void run() 
       {
           //token used for vaildating the received message
            String message, connect = "Connect", disconnect = "Disconnect", chat = "Chat" ;
            String[] data;
            
            try 
            { //run until there is no incoming message from server and not null/empty
                while ((message = reader.readLine()) != null) 
                {
                    //tokenize the received string for validating
                    data = message.split(":");
                    ta_chat.append(" Received -- " + data[1] + " from "+data[0]+"\n");
                
                    //if data received from client has a srting token as "connect", and if the server doesnt have an existing username, it accepts and reads the data from client. 
                    if (data[2].equals(connect)) 
                    {
                        if(allclients.contains(data[0]))
                        {
                            tellOnlyone(data[0],client);
                        } 
                        else{ 
                        tellallclients((data[0] + ":" + data[1] + ":" + chat));
                        userAdd(data[0]);
                    }
                    }
                    
                    //if the string token says "disconnect", the client is removed from allclients list, and the same message is passed to all allclients using method "tellallclients(message)"
                    else if (data[2].equals(disconnect)) 
                    {
                        
                        tellallclients((data[0] + ":has disconnected." + ":" + chat));
                        userRemove(data[0]);
                    } 
                    
                    // if the string token contains "chat", the message is broadcasted to all the allclients using tellallclients(message)
                    else if (data[2].equals(chat)) 
                    {
                        tellallclients(message);
                    } 
                    // if a new file notification is received, that file is transfered to other client using transferfile() along with a message using method TellEveryone(message);
                    else if (data[2].equals(" new file added "))
                    {
                        tellallclients(message);  
                       transferfile(data[0],"D:\\"+data[0]+"\\shared_directory\\"+data[3]);
                    }
                    // if an existing file is modified, an invalidation notice is sent to the server, which pushes the updated file to the other clients
                    else if (data[2].equals(" file is modified "))
                    {
                        tellallclients(message);
                        ta_chat.append("\n"+data[0]+"::: INVALIDATION NOTICE ::: on file "+data[3] +"\n\n");
                        tellallclients(data[0]+":INVALIDATION NOTICE:"+"Chat:"+data[3] );
                       transferfile(data[0],"D:\\"+data[0]+"\\shared_directory\\"+data[3]);
                    }
                    // if the incoming message has deleted info, initiate the client as coordinator and receive votes from other clients
                    else if (data[2].equals(" file deleted "))
                    {
                        coordinator = data[0];  // storing the coordinator variable to the client which deleted the file
                        deletefilepath = data[3];   // storing the filepath variable to the path of the deleted file
                        tellallclients(message);
                        ta_chat.append("\n"+data[0]+"::: DELETION INSTRUCTION ::: on file "+data[3] +"\n\n");
                        tellallclients(data[0]+":DELETION INSTRUCTION:"+"Chat:"+data[3] );
                      
                    }
                    
                    // voting response from clients, if atleast one vote is Abort, the final decision is Abort
                    // if all votes are Commit, it wont change the default value for votingdecision i.e commit
                    else if (data[3].equals("vote"))
                    {
                         if(data[2].equals("Abort"))
                        {
                            votingdecision = "Abort";
                        }
                        
                       // for every vote, we will increment the votescounter, to check the if loop beneath this
                        countofvotes++;
                      // sending the vote message to every client
                        ta_chat.append("\n"+data[0]+"::: Voting Decision :::  "+data[2] +"\n\n");
                        tellallclients(data[0]+":Voting Decision:"+"Chat:"+data[2] );
                      
                          // if all the votes are received from all the clients, decide to Commit/Abort and pass the same instruction to all the clients
                        if(countofvotes==(allclients.size()-1))
                        {
                            countofvotes=0;
                            
                           // if voting decision is abort, pass the global Abort decision to all clients
                            if(votingdecision.equals("Abort"))
                            {
                                votingdecision="Commit";
                                ta_chat.append("\n"+coordinator+":Global Abort on file:Chat:"+deletefilepath+"\n\n");
                                tellallclients(coordinator+":Global Abort on file:Chat:"+deletefilepath);
                            }
                            //  if voting decision is Commit, pass the global Commit decision to all clients
                            else
                            {
                                ta_chat.append("\n"+coordinator+":Global Commit on file:Chat:"+deletefilepath+"\n\n");
                                tellallclients(coordinator+":Global Commit on file:Chat:"+deletefilepath);
                            }
                        }
                        
                         
                        
                    }
                    
                   //if no tokens are matching, print no conditions met
                    else 
                    {
                        ta_chat.append(" No Conditions were met. \n");
                    }
                } 
             } 
            //if any interruption / disconnection exists from clients
             catch (Exception ex) 
             {
                ta_chat.append(" Lost a connection. \n");
                ex.printStackTrace();
                Costreams.remove(client);
                
             } 
	} 
    
   
  
   }
   
    public void closeconnection(int numberOfusers)
   {
      try
        { 
         if(numberOfusers>0)
         {
            in.close(); 
            out.close();
            sockz.close();
         }
             
            serverSock.close();
        } 
        catch(IOException i) 
        { 
           // System.out.println(i); 
        } 
   }
   
// inherited method to initiate the GUI components
    public server_frame() 
    {
        initComponents();
    }

   // https://github.com/jumimioto/PR/blob/master/PR%20lab5/Chat_Server/Chat_Server/src/chat_server/server_frame.java
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        ta_chat = new javax.swing.JTextArea();
        b_start = new javax.swing.JButton();
        b_end = new javax.swing.JButton();
        b_users = new javax.swing.JButton();
        b_clear = new javax.swing.JButton();
        lb_name = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jSpinner1 = new javax.swing.JSpinner();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Chat - Server's frame");
        setBounds(new java.awt.Rectangle(250, 250, 0, 0));
        setName("server"); // NOI18N
        setResizable(false);

        ta_chat.setBackground(new java.awt.Color(192, 227, 243));
        ta_chat.setColumns(20);
        ta_chat.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        ta_chat.setRows(5);
        jScrollPane1.setViewportView(ta_chat);

        b_start.setText("START SERVER");
        b_start.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_startActionPerformed(evt);
            }
        });

        b_end.setText("STOP SERVER");
        b_end.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_endActionPerformed(evt);
            }
        });

        b_users.setText("CONNECTED CLIENTS");
        b_users.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_usersActionPerformed(evt);
            }
        });

        b_clear.setText("CLEAR");
        b_clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_clearActionPerformed(evt);
            }
        });

        lb_name.setText("Omkar Kyatham");
        lb_name.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lb_name.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lb_nameMouseClicked(evt);
            }
        });

        jButton1.setText("KILL SERVER");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setLabel("CREATE CLIENT");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(b_end, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(b_start, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
                                .addComponent(lb_name)
                                .addGap(66, 66, 66))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(b_users, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(b_clear, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 328, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(b_start)
                    .addComponent(b_users))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(lb_name)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(b_clear)
                            .addComponent(jButton2)
                            .addComponent(jSpinner1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(b_end)
                            .addComponent(jButton1))
                        .addContainerGap())))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    //method to end the connection from server side and remove all the clients connection
    private void b_endActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_endActionPerformed
      int size = allclients.size();
      allclients.clear();
      
       tellallclients(" Server:is stopping and all users will be disconnected.:Serverdisconnect");
        ta_chat.append(" Server stopping... \n");
        ta_chat.setText("");
       closeconnection(size);
             
    }//GEN-LAST:event_b_endActionPerformed
    
    //the method to start the server thread 
    private void b_startActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_startActionPerformed
        Thread starter = new Thread(new ServerStart());
        starter.start();
      
       
    }//GEN-LAST:event_b_startActionPerformed

    //method to print all the connected allclients and printing it to the GUI
    private void b_usersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_usersActionPerformed
        ta_chat.append("\n Online users : \n");
        for (String current_user : allclients)
        {
            ta_chat.append(current_user +"\n");
          
        }    
        
    }//GEN-LAST:event_b_usersActionPerformed
    //method to clear the textArea on server GUI
    private void b_clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_clearActionPerformed
        ta_chat.setText("");
    }//GEN-LAST:event_b_clearActionPerformed
    //close the server GUI without using close window operation
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        tellallclients(" Server:is stopping and all users will be disconnected.:Serverdisconnect");
       
       
        System.exit(0);
    }//GEN-LAST:event_jButton1ActionPerformed
//hyperlink to a component on GUI to my personal site && out of syllabus
  //  https://stackoverflow.com/questions/4511856/open-web-page-from-jframe
    private void lb_nameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lb_nameMouseClicked
        // TODO add your handling code here:
         try {
            Desktop.getDesktop().browse(new URI("www.linkedin.com/in/kyathamomkar"));
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (URISyntaxException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }//GEN-LAST:event_lb_nameMouseClicked

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
     String val = jSpinner1.getValue() + "";
    int value= Integer.parseInt(val);
        for(int i=0;i<value;i++)
        new client_frame().setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed
    // the main program execution starts from here, creating the GUI
    public static void main(String args[]) 
    {
        java.awt.EventQueue.invokeLater(new Runnable() 
        {
            @Override
            public void run() {
                new server_frame().setVisible(true);
            }
        });
    }
    
    //server class to initiate the running of socket which implements the interface Runnnable
    //https://coderanch.com/t/551759/java/Simple-Chat
    public class ServerStart implements Runnable 
    {
        @Override
        public void run() 
        {
            //the variables for connected allclients and outputstreams
            Costreams = new ArrayList();
            allclients = new ArrayList();  

            try 
            {
                //creation a socket at port 2222 
                 serverSock = new ServerSocket(2222);
                 ta_chat.append("Server started...\n");
                while (true) 
                {
                        //accepting all the connections to socket at port 2222 
				Socket clientSock = serverSock.accept();
				PrintWriter writer = new PrintWriter(clientSock.getOutputStream());
                                
                                //getting the outputstream of newly added client so as to communicate from the server
				Costreams.add(writer);
                               
                                //starting a thread to handle this newly added client via passing the socket object, and its outputstream 
				Thread listener = new Thread(new ClientHandler(clientSock, writer));
				listener.start();
				ta_chat.append(" Got a connection. \n");
                                
                                 
                }
            }
            //incase if you start the server if it is already running, it prints below to the chat area
            catch (Exception ex)
            {
                ta_chat.append(ex.getMessage()+"\n");
            }
        }
    }
    //for every newly added client, the server is going to add that client to its global list -allclients and prints all the allclients to GUI once added.
    //https://ideone.com/n2H9Zg
    public void userAdd (String data) 
    {
        String message, add = ": :Connect", done = "Server: :Done", name = data;
        countofusers++;
       // ta_chat.append("Before " + name + " added. \n");
        allclients.add(name);
        ta_chat.append(" After " + name + " added, users are \n");
        String[] tempList = new String[(allclients.size())];
        allclients.toArray(tempList);
//printing the allclients to the text area 
        for (String token:tempList) 
        {
            ta_chat.append(token + ", ");
          
        } ta_chat.append("\n");        
    }
    //if a user disconnects, the user is removed from the global list "allclients"
    //https://ideone.com/n2H9Zg
    public void userRemove (String data) 
    {
        String message, add = ": :Connect", done = "Server: :Done", name = data;
        allclients.remove(name);
        String[] tempList = new String[(allclients.size())];
        allclients.toArray(tempList);
        
        for (String token:tempList) 
        {
            message = (token + add);
            tellallclients(message);
        }
        tellallclients(done);
    }
    //broadcasting the message from server to all clients through outputstreams for each clients
    //https://forum.allaboutcircuits.com/threads/java-reading-from-a-socket-using-a-bufferedreader-object.104212/
    public void tellallclients(String message) 
    {
	Iterator it = Costreams.iterator();
        
        while (it.hasNext()) 
        {
            try 
            {
                PrintWriter writer = (PrintWriter) it.next();
		writer.println(message);
		//ta_chat.append("Sending: " + message + "\n");
                writer.flush();
               // ta_chat.setCaretPosition(ta_chat.getDocument().getLength());

            } 
            catch (Exception ex) 
            {
		ta_chat.append(" Error telling everyone. \n");
            }
        } 
    }
         //passing message to only newly added client if the username entered is duplicate or already connected
      public void tellOnlyone(String message, PrintWriter clientstream) 
    {
            try 
            {
                //sending message to one client using outputstream and printing it to servers text area
            	clientstream.println(message+ " : name is already in use please :reconnect:\n");
		ta_chat.append(message+ " : name is already in use please :reconnect:\n");
                clientstream.flush();
                ta_chat.setCaretPosition(ta_chat.getDocument().getLength());

            } 
            catch (Exception ex) 
            {
		ta_chat.append("Error telling everyone. \n");
            }
         Costreams.remove(clientstream);
   }  
    
    //broadcasting the new file to all clients using commons.io
    public void transferfile(String sender, String source_path)
    {
        File originalsourceFile = new File(source_path);
        String name = originalsourceFile.getName();
      
        //sending it to other clients
        String[] tempList = new String[(allclients.size())];
        allclients.toArray(tempList);
        
        //get all the allclients, traverse through each of them to transfer the file
        for (String token:tempList) 
        {
            if(!token.equals(sender))
            {
            try {
            String target = "D:\\"+token+"\\incoming_files\\";
     
        //copying the file from source client to other client
        File targetFile = new File(target+name);
        ta_chat.append(" Transfering file " + name +" from "+sender+" to "+token +"\n");
     
        //copy file from one location to other
        FileUtils.copyFile(originalsourceFile, targetFile);
        }
            
            catch(Exception e){
                //ta_chat.append("error in transfering source file from server to "+token+" "+e.getMessage()+ "\n");
            
            }
        }
        }
        ta_chat.append(" File Transfer completed to all clients\n\n");
        
    }
    
   
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b_clear;
    private javax.swing.JButton b_end;
    private javax.swing.JButton b_start;
    private javax.swing.JButton b_users;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JLabel lb_name;
    private javax.swing.JTextArea ta_chat;
    // End of variables declaration//GEN-END:variables
}
