//NAME : OMKAR KYATHAM
//STUDENTID : 1001765567

//the package for the client class
package chat_client;
//useful java libraries for various actions of the program
import java.awt.Desktop;
import java.net.*;
import java.io.*;
import java.util.*;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import jdk.nashorn.internal.objects.NativeArray;
import org.apache.commons.io.FileUtils;

//the main class which handles the client operations along with the GUI
public class client_frame extends javax.swing.JFrame 
{
    //variables to store the clients username, current connected allclients, socket port, socket object, buffered reader, outputstream object;
    String username, address = "localhost";
    ArrayList<String> allclients = new ArrayList();
    int port = 2222;
    Boolean checkifconnected = false;
    
    Socket sock;
    BufferedReader reader;
    PrintWriter writetoserver;
    
    //concurrent threads for bufferedreader, monitoring the directory for a newfile, //
    //https://ideone.com/n2H9Zg
    public void ListenThread() 
    {
         Thread IncomingReader = new Thread(new IncomingReader());
         IncomingReader.start();
         
         Thread Monitor_directory = new Thread(new Monitor_directory());
         Monitor_directory.start();
         
         Thread Monitor_incomingdirectory = new Thread(new Monitor_incomingdirectory());
         Monitor_incomingdirectory.start();
         
        
         
    }
    
    //when a new user connects to the server, the client store the name to its global variable allclients//
    //https://ideone.com/n2H9Zg
    public void addnewuser(String data) 
    {
         allclients.add(data);
    }
    
    //when a user gets disconnected, print it to the GUI//
    //https://ideone.com/n2H9Zg
    public void deleteuser(String data) 
    {
         ta_chat.append(data + " is now offline.\n");
    }
    
    //when server completes some operation, the done status is passed onto other clients//
    //update - no use
    //https://ideone.com/n2H9Zg
    public void printusers() 
    {
         String[] tempList = new String[(allclients.size())];
         allclients.toArray(tempList);
         for (String token:tempList) 
         {
             //users.append(token + "\n");
         }
    }
    
    //when user clicks on disconnect on the GUI, the disconnection message is passed on to the client via writetoserver outputstream//
    //https://ideone.com/n2H9Zg
    public void sendingdiscon() 
    {
        String bye = (username + ":disconnection :Disconnect");
        try
        {
            //sending message to server about disconnection
            writetoserver.println(bye); 
            writetoserver.flush(); 
        } catch (Exception e) 
        {
            ta_chat.append("Could not send Disconnect message.\n");
        }
    }

    //--------------------------//
    
    //closing the socket and deleting the shared folders
    //https://ideone.com/n2H9Zg
    public void Disconnect(String removefolder) 
    {
        try 
        {
            //closing socket and printing it on text area. and removing the folders only if true is passed as argument
            ta_chat.append("Disconnected.\n");
            sock.close();
            if(removefolder.equals("true")){deletefolders();}
            
        } catch(Exception ex) {
            ta_chat.append("Failed to disconnect. \n");
        }
        checkifconnected = false;
        tf_username.setEditable(true);

    }
    //method which initiates the GUI
    //https://ideone.com/n2H9Zg
    public client_frame() 
    {
        initComponents();
    }
    
    //every message from server, it identifies what the message is about using token from the string received//
    //https://ideone.com/n2H9Zg
    public class IncomingReader implements Runnable
    {
        @Override
        public void run() 
        {
            String[] data;
            String stream, done = "Done", connect = "Connect", disconnect = "Disconnect", chat = "Chat";

            try 
            {
                while ((stream = reader.readLine()) != null) 
                {
                     data = stream.split(":");
                     //if the message has chat, it prints to the GUI
                     if (data[2].equals(chat)) 
                     {  //if file invalidation is the message, print the following txt
                         if(data[1].equals("INVALIDATION NOTICE"))
                         {
                             if(!data[0].equals(username)){
                             ta_chat.append(data[0] + ": " + data[1] + " on file "+data[3]+"\n Updated "+data[3]+" file received... \n");
                        ta_chat.setCaretPosition(ta_chat.getDocument().getLength());
                         }
                         }
                         //if it is a deletion instruction, generate the vote and send it to the coordinator using sendnotification();
                         else if(data[1].equals("DELETION INSTRUCTION"))
                         {
                             
                             if(!data[0].equals(username)){
                                  ta_chat.append(data[0] + ": " + data[1] + " on file "+data[3]+"\n");
                                  ta_chat.setCaretPosition(ta_chat.getDocument().getLength());
                                 TimeUnit.SECONDS.sleep(5);
                                 List<String> givenList = Arrays.asList("Commit", "Abort");
                                 Random rand = new Random();
                                 String randomElement = givenList.get(rand.nextInt(givenList.size()));
                                 ta_chat.append("\nmy vote is "+randomElement+"\n\n");
                                 sendnotification("vote", randomElement);
                            
                         }
                         }
                         //if the message contains voting decision from other clients, print the following to textarea.
                         else if(data[1].equals("Voting Decision"))
                         {
                            
                                ta_chat.append(data[0] + ": " + data[1] + " is "+data[3]+"\n");
                                ta_chat.setCaretPosition(ta_chat.getDocument().getLength());
                         
                         }
                         
                         //if the message contains the global voting decision as Abort,
                         //do not delete the file on the current client but copy a file to the coordinator's folder
                         else if (data[1].equals("Global Abort on file"))
                         {
                             if(!data[0].equals(username)){
                             File originalsourceFile = new File("D:\\"+username+"\\incoming_files\\"+data[3]);
                              File targetFile = new File("D:\\"+data[0]+"\\shared_directory\\"+data[3]);
                             //copy the file to the client who deleted it. 
                             FileUtils.copyFile(originalsourceFile, targetFile);
                             }
                             // if the coordinator and the current client are same, the file is recovered text is printed
                             else
                             {
                               ta_chat.append("\nGlobal Abort :: "+data[3]+" file recovered\n\n");   
                             }
                         }
                         
                         //if the message contains global commit, the file should be deleted on the folder for the current client
                         else if(data[1].equals("Global Commit on file")&&!data[0].equals(username))
                         {
                             recursiveDelete(new File("D:\\"+username+"\\incoming_files\\"+data[3]));
                             ta_chat.append("\nGlobal Commit :: "+data[3]+" \nfile deleted\n\n");
                         }
                         
                         
                         
                         else{
                             
                           /*  if(data[4].equals("BROADCAST")||data[4].equals(username))
                             {  */
                       //   ta_chat.append(data[0]+","+data[1]+","+data[2]+","+data[3]+","+data[4]+ "\n");
                       if(data.length>3)
                       {
                           if(data[4].equals("BROADCAST")||data[4].equals(username))
                           {
                          ta_chat.append(data[0] + ": " + data[1] + "\n");
                        ta_chat.setCaretPosition(ta_chat.getDocument().getLength());
                           }
                       }
                       else{
                        ta_chat.append(data[0] + ": " + data[1] + "\n");
                        ta_chat.setCaretPosition(ta_chat.getDocument().getLength());
                             }
                     } 
                     }
                     //if the message has " newfile added", the username and address of file is sent to server
                   else if (data[2].equals(" new file added ")||data[2].equals(" file is modified ")) 
                     {
                        ta_chat.append(data[0] + ": " + data[1] + "\n");
                        ta_chat.setCaretPosition(ta_chat.getDocument().getLength());
                     } 
                   // if message has serverdisconnect token, the client initiates the disconnection process from its end.
                   else if (data[2].equals("Serverdisconnect"))
                   {
                       sendingdiscon();
                       Disconnect("true");                       
                   }
                   //if  a new client adds, it is added to the allclients list.
                     else if (data[2].equals(connect))
                     {
                        ta_chat.removeAll();
                        addnewuser(data[0]);
                     } 
                     //if the message is equal to disconnect , the client is removed from allclients list
                     else if (data[2].equals(disconnect)) 
                     {
                         deleteuser(data[0]);
                     } 
                     // if it is done, then it means server operation is completed. update: no use
                     else if (data[2].equals(done)) 
                     {
                        //users.setText("");
                        printusers();
                        allclients.clear();
                     }
                     //if the server responds with reconnect, which means the username entered by user is already taken by other client
                    else if (data[2].equals("reconnect"))
                     {
                         ta_chat.append(" Please choose another name \n");
                        
                         Disconnect("false");
                     } 
                }
           }catch(Exception ex) { }
        }
    }
    // a class for monitoring any changes to the shared directory using thread and filesystem
    // source :  https://javapapers.com/core-java/monitor-a-folder-using-java/
    // https://docs.oracle.com/javase/7/docs/api/java/nio/file/StandardWatchEventKinds.html
    public class Monitor_directory implements Runnable
    {
        @Override
        public void run() 
        {
            try
            {
                //specifying the path to monitor
             Path folder = Paths.get("D:\\"+username+"\\shared_directory");
		WatchService watchService = FileSystems.getDefault().newWatchService();
		folder.register(watchService, StandardWatchEventKinds.ENTRY_CREATE,StandardWatchEventKinds.ENTRY_MODIFY,StandardWatchEventKinds.ENTRY_DELETE);
                String  flag = "flag";
		boolean isvalid = true;
		do {
			WatchKey watchingKey = watchService.take();
                        Thread.sleep( 2000 );
                //if the create event triggers on the folder, it passes the file name and address
			for (WatchEvent event : watchingKey.pollEvents().subList(0, 1)) {
				WatchEvent.Kind kind = event.kind();
                            if (StandardWatchEventKinds.ENTRY_CREATE.equals(event.kind())) {  flag="false";
					String newfileName = event.context().toString();
					tf_chat.setText(" New File Created - " + newfileName );
                                       filesarea.append(" New File "+newfileName+" added \n");
                                        sendnotification(newfileName, "false");
                                        printallfiles();
                                       
				}
                                // laB 2 UPDATE : if a file gets modified in the particular directory, the modify event triggers on the folder, it passes the file name and address
                                else if (StandardWatchEventKinds.ENTRY_MODIFY.equals(event.kind())&&flag.equals(""))
                                {
                                        String newfileName = event.context().toString();
					tf_chat.setText(" File Modified - " + newfileName );
                                        sendnotification(newfileName, "true");
                                       
                                }
                            // LAB 3 UPDATE :: if an entry in directory is deleted, message will be triggered.  
                             else if (StandardWatchEventKinds.ENTRY_DELETE.equals(event.kind())&&flag.equals(""))
                                {
                                        String deletedfilename = event.context().toString();
					tf_chat.setText(" File Deleted - " + deletedfilename );
                                        //the current clients acts as a coordinator upon a deletion in its hared folder.
                                        ta_chat.append("File Deleted "+deletedfilename+" \n Acting as Coordinator \n");
                                        sendnotification(deletedfilename, "delete");
                                       
                                }
                            
                            
                            
                            
			}
			isvalid = watchingKey.reset();
                        flag="";
		} while (isvalid);   
            }
            catch(Exception e) {}
                           
            
        }
    }
    
    //a class for monitoring the received files using thread and filesystem
    // source :  https://javapapers.com/core-java/monitor-a-folder-using-java/
     public class Monitor_incomingdirectory implements Runnable
    {
        @Override
        public void run() 
        {
            try
            {
                //specifying the path to monitor
             Path folder = Paths.get("D:\\"+username+"\\incoming_files");
		WatchService watchService = FileSystems.getDefault().newWatchService();
		folder.register(watchService, StandardWatchEventKinds.ENTRY_CREATE);

		boolean isvalid = true;
		do {
			WatchKey watchingKey = watchService.take();
                        //if the create event triggers on the folder, it passes the file name and address 
			for (WatchEvent event : watchingKey.pollEvents()) {
				WatchEvent.Kind kind = event.kind(); 
				if (StandardWatchEventKinds.ENTRY_CREATE.equals(event.kind())) {
					
                                        printallfiles();
				}
			}
			isvalid = watchingKey.reset();

		} while (isvalid);   
            }
            catch(Exception e) {}
                           
            
        }
    }
    
     // method to print all the files 
     // source :https://javaconceptoftheday.com/list-all-files-in-directory-in-java/
     
     public void printallfiles()
     {
         //get all the files from shared directory and incoming files and print them to files area on GUI
          File incoming = new File("D:\\"+username+"\\incoming_files");
          File sharedD  = new File("D:\\"+username+"\\shared_directory");
        File[] incomingfiles = incoming.listFiles();
        File[] sharedfiles   = sharedD.listFiles();
        filesarea.append(" \nThe current files in the directory :\n");
        for (File file : sharedfiles)
        {
            filesarea.append(file.getName()+"\n");
        }
        for (File file : incomingfiles)
        {
            filesarea.append(file.getName()+"\n");
        }
         
     }
    
    
    // method to transfer the notification to server about the new file added in shared directory passing the username of client and file address
    public void sendnotification(String newfilename, String modification)
    {
        //assigning the file name and address to text field
        String message="";
        if(modification.equals("true"))
        {
              message = " file is modified ";
        }
        else if(modification.equals("delete"))
        {
            message = " file deleted ";
        }
        else if(newfilename.equals("vote"))
        {
            message = modification;
             tf_chat.setText(" ");
        }
        else{
              message = " new file added ";
        }
        
        if ((tf_chat.getText()).equals("")) {
            tf_chat.setText("");
            tf_chat.requestFocus();
        } else {
            try {
                //printing that message from text field to server
               writetoserver.println(username + ":" + tf_chat.getText() + ":" + message + ":" + newfilename);
               writetoserver.flush(); // flushes the buffer
            } catch (Exception ex) {
                ta_chat.append("Message was not sent. \n");
            }
            tf_chat.setText("");
            tf_chat.requestFocus();
        }
        // keeping the text field back to empty 
        tf_chat.setText("");
        tf_chat.requestFocus();
    }
    
    //delete the shared folders recursively after client disconnects 
    //source : https://www.journaldev.com/833/java-delete-directory-folder
    
    public void deletefolders()
    {
        String dir = "D:\\"+username;
        //delete folder recursively
        recursiveDelete(new File(dir));
    }
    
    //recursive way to delete the files and folders
      //source : https://www.journaldev.com/833/java-delete-directory-folder
    public static void recursiveDelete(File dir) {
        //to end the recursive loop
        if (!dir.exists())
            return;
        
        //if it is a directory again, look inside it and call same method recursively
        if (dir.isDirectory()) {
            for (File f : dir.listFiles()) {
                //call recursively
                recursiveDelete(f);
            }
        }
        //call delete to delete files and empty directory
        dir.delete();
    }
    
    //--------------------------//
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lb_address = new javax.swing.JLabel();
        tf_address = new javax.swing.JTextField();
        lb_port = new javax.swing.JLabel();
        tf_port = new javax.swing.JTextField();
        lb_username = new javax.swing.JLabel();
        tf_username = new javax.swing.JTextField();
        b_connect = new javax.swing.JButton();
        b_disconnect = new javax.swing.JButton();
        b_anonymous = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        ta_chat = new javax.swing.JTextArea();
        tf_chat = new javax.swing.JTextField();
        b_send = new javax.swing.JButton();
        lb_name = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        filesarea = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        dropdown = new javax.swing.JComboBox<>();
        recipient = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Chat - Client's frame");
        setBounds(new java.awt.Rectangle(250, 250, 0, 0));
        setName("client"); // NOI18N
        setResizable(false);

        lb_address.setText("Address : ");

        tf_address.setText("localhost");
        tf_address.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf_addressActionPerformed(evt);
            }
        });

        lb_port.setText("Port :");

        tf_port.setText("2222");
        tf_port.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf_portActionPerformed(evt);
            }
        });

        lb_username.setText("Username :");

        tf_username.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tf_usernameActionPerformed(evt);
            }
        });

        b_connect.setText("Connect");
        b_connect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_connectActionPerformed(evt);
            }
        });

        b_disconnect.setText("Disconnect");
        b_disconnect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_disconnectActionPerformed(evt);
            }
        });

        b_anonymous.setText("Anonymous Login");
        b_anonymous.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_anonymousActionPerformed(evt);
            }
        });

        ta_chat.setBackground(new java.awt.Color(255, 255, 204));
        ta_chat.setColumns(20);
        ta_chat.setFont(new java.awt.Font("Tahoma", 1, 15)); // NOI18N
        ta_chat.setRows(5);
        jScrollPane1.setViewportView(ta_chat);

        b_send.setText("SEND");
        b_send.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                b_sendActionPerformed(evt);
            }
        });

        lb_name.setText("Omkar Kyatham");
        lb_name.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        lb_name.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lb_nameMouseClicked(evt);
            }
        });

        jButton1.setText("List files");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Kill the client");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        filesarea.setColumns(20);
        filesarea.setRows(5);
        jScrollPane2.setViewportView(filesarea);

        jLabel1.setText("Current Files");

        jButton3.setText("Clear");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        dropdown.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "MULTICAST", "UNICAST", "BROADCAST" }));
        dropdown.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dropdownActionPerformed(evt);
            }
        });

        recipient.setToolTipText("");
        recipient.setEnabled(false);
        recipient.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                recipientActionPerformed(evt);
            }
        });

        jButton4.setText("Check Messages");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lb_address, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lb_username, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(tf_address, javax.swing.GroupLayout.DEFAULT_SIZE, 113, Short.MAX_VALUE)
                            .addComponent(tf_username))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(39, 39, 39)
                                .addComponent(lb_port, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(tf_port, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(b_anonymous, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(37, 37, 37)
                                .addComponent(b_connect, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(b_disconnect)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tf_chat, javax.swing.GroupLayout.PREFERRED_SIZE, 352, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lb_name))
                        .addGap(12, 12, 12)
                        .addComponent(dropdown, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(recipient)
                            .addComponent(b_send, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(56, 56, 56)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton3)
                            .addComponent(jLabel1)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, 155, Short.MAX_VALUE))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_address)
                    .addComponent(tf_address, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lb_port)
                    .addComponent(tf_port, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(b_anonymous)
                    .addComponent(jButton3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lb_username)
                    .addComponent(b_connect)
                    .addComponent(b_disconnect)
                    .addComponent(jButton1)
                    .addComponent(tf_username)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 322, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(tf_chat)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lb_name))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(dropdown, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(recipient, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(b_send)
                            .addComponent(jButton2))
                        .addGap(0, 13, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tf_addressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf_addressActionPerformed
       
    }//GEN-LAST:event_tf_addressActionPerformed

    private void tf_portActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf_portActionPerformed
   
    }//GEN-LAST:event_tf_portActionPerformed

    private void tf_usernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tf_usernameActionPerformed
    
    }//GEN-LAST:event_tf_usernameActionPerformed
//creates a socket, and requests for connection to the server. 
    // once connected, it creates the shared directories
    private void b_connectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_connectActionPerformed
       if(!tf_username.getText().equals("")){
           //if only it is not connected
        if (checkifconnected == false) 
        {
            username = tf_username.getText();
            tf_username.setEditable(false);
            File in_files = new File("D:\\"+username+"\\incoming_files");
                 File out_files = new File("D:\\"+username+"\\shared_directory");
             if(!in_files.exists()&&!out_files.exists())
                 {
            try 
            {
                //specifying the socket details for establishment, buffered reader for incoming messages from server, outputstream print writetoserver for outgoing messages
                sock = new Socket(address, port);
                InputStreamReader streamreader = new InputStreamReader(sock.getInputStream());
                reader = new BufferedReader(streamreader);
                writetoserver = new PrintWriter(sock.getOutputStream());
                writetoserver.println(username + ":has connected.:Connect");
                writetoserver.flush(); 
                checkifconnected = true; 
                //creating the shared and incoming files directories
                 in_files.mkdirs();
                 out_files.mkdirs();
                 ListenThread();
                 
            } 
            catch (Exception ex) 
            {
                ta_chat.append("Cannot Connect! Try Again. \n");
                tf_username.setEditable(true);
            }
            
                 }
             else
             {
                 ta_chat.append("Name already taken. Reconnect\n");
                 checkifconnected = false;
            tf_username.setEditable(true);
             }
            
        }
        //if the client is already connected, but still clicks on connect button
        else if (checkifconnected == true) 
        {
            ta_chat.append("You are already connected. \n");
        }
        
    }//GEN-LAST:event_b_connectActionPerformed
      //if the client clicks the connect button withoiut entering the name
       else{
            ta_chat.append("Please enter a username first \n");
       }
    }
    //if the disconnect button is clicked on the GUI
    //https://ideone.com/n2H9Zg
    private void b_disconnectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_disconnectActionPerformed
        sendingdiscon();
        Disconnect("true");
    }//GEN-LAST:event_b_disconnectActionPerformed
    //the client is connected by a random username to the server
    //https://ideone.com/n2H9Zg
    private void b_anonymousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_anonymousActionPerformed
        tf_username.setText("");
        if (checkifconnected == false) 
        {
            //generating a random name for username
            String anon="anon";
            Random generator = new Random(); 
            int i = generator.nextInt(999) + 1;
            String is=String.valueOf(i);
            anon=anon.concat(is);
            username=anon;
            //setting the random name ot text field 
            tf_username.setText(anon);
            tf_username.setEditable(false);
            //steps to establish a connection to the server
            try 
            {
                //repeating the same procedure for establishment of connection
                sock = new Socket(address, port);
                InputStreamReader streamreader = new InputStreamReader(sock.getInputStream());
                reader = new BufferedReader(streamreader);
                writetoserver = new PrintWriter(sock.getOutputStream());
                writetoserver.println(anon + ":has connected.:Connect");
                writetoserver.flush(); 
                checkifconnected = true; 
            } 
            catch (Exception ex) 
            {
                ta_chat.append("Cannot Connect! Try Again. \n");
                tf_username.setEditable(true);
            }
            
            ListenThread();
            
        } else if (checkifconnected == true) 
        {
            ta_chat.append("You are already connected. \n");
        }        
    }//GEN-LAST:event_b_anonymousActionPerformed
    //the message entered in the chat GUI is sent to the server through the output stream
    //https://ideone.com/n2H9Zg
    private void b_sendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_b_sendActionPerformed
        String nothing = "";
        String message_mode ="";
        String recipient_name= "";
        String[] individual_clients;
        Boolean flag = false;
        //only if text message is not empty, pass the message to server
        if ((tf_chat.getText()).equals(nothing)) {
            tf_chat.setText("");
            tf_chat.requestFocus();
        } else {
            try {
                if(dropdown.getSelectedItem().equals("BROADCAST"))
                {
                    message_mode = "BROADCAST";
                    recipient_name ="BROADCAST";
                    flag= true;
                }
              else if(dropdown.getSelectedItem().equals("MULTICAST"))
                {
                    message_mode = "MULTICAST";
                     recipient_name =  recipient.getText();
                     
                       if(recipient_name.equals(""))
                       {
                            ta_chat.append("Please enter recipient name as s1,s2,s3 \n");
                       }
                       else
                       {
                           flag= true;
                           individual_clients = recipient_name.split(",");
                           for (String individual_client : individual_clients) {
                            
                                File f = new File("D:\\"+individual_client+".txt"); 
                                if(!f.exists())
                       {
                           flag =false;
                       }
                           }
                           
                           if(!flag)
                           {
                               ta_chat.append("Client list has invalid username \n");
                           }
                            
                       }
                }
                else
                {
                       message_mode = "UNICAST";
                       recipient_name =  recipient.getText();
                        File f = new File("D:\\"+recipient_name+".txt"); 
                       if(f.exists())
                       {
                       if(recipient_name.equals(""))
                       {
                            ta_chat.append("Please enter recipient name \n");
                       }
                       else
                       {
                           flag = true;
                       }
                       }
                       else
                       {
                            ta_chat.append("Invalid recipient name. Message Queue doesnt exists \n");
                       }
                }
                
                
                
                
                                
                if(flag){
                //getting text from text field and printing it onto printwriter
               writetoserver.println(username + ":" + tf_chat.getText() + ":" + "message" +":"+message_mode+":"+recipient_name);
               writetoserver.flush(); // flushes the buffer
               
                }
            } catch (Exception ex) {
                ta_chat.append("Message was not sent. \n");
            }
            tf_chat.setText("");
            tf_chat.requestFocus();
        }

        tf_chat.setText("");
        tf_chat.requestFocus();
    }//GEN-LAST:event_b_sendActionPerformed
    //when the user clicks on the list all files, the corresponding method is called
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        printallfiles();
    }//GEN-LAST:event_jButton1ActionPerformed
    //the client is killed when the user clicks on kill button, so client first disconnects and kills the GUI
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
         sendingdiscon();
        Disconnect("true");
        setVisible(false);
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed
    //personal usage . out of project scope
   // https://stackoverflow.com/questions/4511856/open-web-page-from-jframe
    private void lb_nameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lb_nameMouseClicked
        // TODO add your handling code here:
         try {
            Desktop.getDesktop().browse(new URI("www.linkedin.com/in/kyathamomkar"));
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (URISyntaxException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
    }//GEN-LAST:event_lb_nameMouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        ta_chat.setText("");
        filesarea.setText("");
    }//GEN-LAST:event_jButton3ActionPerformed

    private void dropdownActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dropdownActionPerformed
        // TODO add your handling code here:
        if(dropdown.getSelectedItem().equals("UNICAST")||dropdown.getSelectedItem().equals("MULTICAST"))
        {
             ta_chat.append("Please enter the recipient(s) as c1,c2,c3\n");
             recipient.setEnabled(true);
        }
        else
        {
             recipient.setEnabled(false);
        }
    }//GEN-LAST:event_dropdownActionPerformed

    private void recipientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_recipientActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_recipientActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
     try {
            String[] message_token ;
            File f = new File("D:\\"+username+".txt");

            List<String> lines = FileUtils.readLines(f, "UTF-8");
           
             if(lines.size()<2)
             {
                 ta_chat.append("No new messages\n");
             }
             else{
            for (String line : lines) {
                if(!(line.equals("")))
                {
                message_token = line.split(":");
                    
                ta_chat.append(message_token[0]+":"+message_token[1]+"\n");
                message_token = null;
                }
            }
            FileUtils.writeStringToFile(f, "\n");
             }
             
        }
     catch (IOException e) {
            ta_chat.append("Queue file doesnt exist \n");
        }

    }//GEN-LAST:event_jButton4ActionPerformed

    //the main method which starts upon execution of client_frame
    public static void main(String args[]) 
    {
        java.awt.EventQueue.invokeLater(new Runnable() 
        {
            @Override
            public void run() 
            {
                new client_frame().setVisible(true);
            }
        });
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton b_anonymous;
    private javax.swing.JButton b_connect;
    private javax.swing.JButton b_disconnect;
    private javax.swing.JButton b_send;
    private javax.swing.JComboBox<String> dropdown;
    private javax.swing.JTextArea filesarea;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lb_address;
    private javax.swing.JLabel lb_name;
    private javax.swing.JLabel lb_port;
    private javax.swing.JLabel lb_username;
    private javax.swing.JTextField recipient;
    private javax.swing.JTextArea ta_chat;
    private javax.swing.JTextField tf_address;
    private javax.swing.JTextField tf_chat;
    private javax.swing.JTextField tf_port;
    private javax.swing.JTextField tf_username;
    // End of variables declaration//GEN-END:variables
}
